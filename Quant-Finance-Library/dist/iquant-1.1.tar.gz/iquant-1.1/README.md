Python Quantitative Finance Library (iquant)

This is a Python library providing a collection of tools and functionalities for quantitative finance applications. It aims to simplify common tasks and calculations used in various quantitative finance domains.