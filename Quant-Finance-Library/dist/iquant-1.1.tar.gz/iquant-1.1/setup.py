from setuptools import setup, find_packages

setup(
    name='iquant',
    version='1.01',
    description='A simple Python library for quantitative finance.',
    author='Apoorv Yadav',
    packages=find_packages(),
)